This directory contains two examples of GeneCoOccurrence usage including the input data. Please see the most up to date tutorial at our Github: 
https://github.com/clinte14/GeneCoOccurrence?tab=readme-ov-file#tutorial-with-sample-data

